# Run on an unlocked Windows test desktop. Emits one JSON document to stdout.
# Cold is fresh process startup, with normal OS caches. Each backend warms up once.
# Hot samples time a UTF-8 command write through receipt of its reply. Fixture readback
# is outside the timer. Memory is sampled once after the last iteration, not a peak.
[CmdletBinding()]
param(
    [Parameter(Mandatory)][string]$CSharpWorker,
    [string]$Jar = (Join-Path $PSScriptRoot '../target/desktop-agent.jar'),
    [ValidateRange(1, 100)][int]$Iterations = 10
)
$ErrorActionPreference = 'Stop'
if ($env:OS -ne 'Windows_NT' -or ![Environment]::UserInteractive) {
    throw 'An interactive Windows test desktop is required.'
}
$Jar = (Get-Item -LiteralPath $Jar).FullName
$CSharpWorker = (Get-Item -LiteralPath $CSharpWorker).FullName
$javaExe = (Get-Command java.exe -CommandType Application | Select-Object -First 1).Source
$fixtureScript = (Get-Item -LiteralPath (Join-Path $PSScriptRoot '../src/test/resources/windows-gui-fixture.ps1')).FullName
$fixtureExe = Join-Path $env:SystemRoot 'System32/WindowsPowerShell/v1.0/powershell.exe'

function Request($cli, $command) {
    $command.id = [guid]::NewGuid().ToString()
    $line = ConvertTo-Json -Compress -Depth 5 $command
    $frame = [Text.Encoding]::UTF8.GetBytes($line + "`n")
    $timer = [Diagnostics.Stopwatch]::StartNew()
    $cli.StandardInput.BaseStream.Write($frame, 0, $frame.Length)
    $cli.StandardInput.BaseStream.Flush()
    $next = $cli.StandardOutput.ReadLineAsync()
    if (!$next.Wait(30000)) { throw "Timed out waiting for $($command.op)." }
    $timer.Stop()
    $reply = $next.Result | ConvertFrom-Json
    if (!$reply.ok -or $reply.id -ne $command.id) { throw "$($command.op) failed: $($reply.error.code)" }
    return @{ ms = $timer.Elapsed.TotalMilliseconds; result = $reply.result }
}

function Wait-State($file, $value) {
    $timer = [Diagnostics.Stopwatch]::StartNew()
    do {
        $actual = $null
        try { $actual = [IO.File]::ReadAllText((Join-Path $stateDir $file)) } catch [IO.IOException] {}
        if ($actual -ceq $value) { return }
        if ($fixture.HasExited) { throw 'Fixture exited unexpectedly.' }
        Start-Sleep -Milliseconds 25
    } while ($timer.Elapsed.TotalSeconds -lt 20)
    throw "Fixture did not report expected $file."
}

function Worker-Process($cli) {
    try {
        $children = @(Get-CimInstance Win32_Process -Filter "ParentProcessId=$($cli.Id)")
        if ($children.Count -eq 1) { return Get-Process -Id $children[0].ProcessId -ErrorAction Stop }
    } catch {}
    return $null
}

function Memory-Sample($process) {
    if (!$process) { return @{ available = $false } }
    try {
        $process.Refresh()
        return @{ available = $true; pid = $process.Id; privateBytes = $process.PrivateMemorySize64
            workingSetBytes = $process.WorkingSet64 }
    } catch { return @{ available = $false } }
}

function Measure-Backend([string]$backend) {
    $start = New-Object Diagnostics.ProcessStartInfo
    $start.FileName = $javaExe
    $start.Arguments = "-jar `"$Jar`" --allow-pid $($fixture.Id) --allow-action invoke --allow-action setValue"
    if ($backend -eq 'CSharp') { $start.Arguments += " --csharp-worker `"$CSharpWorker`"" }
    $start.UseShellExecute = $false
    $start.RedirectStandardInput = $true
    $start.RedirectStandardOutput = $true
    $start.StandardOutputEncoding = [Text.Encoding]::UTF8
    $cold = [Diagnostics.Stopwatch]::StartNew()
    $cli = [Diagnostics.Process]::Start($start)
    try {
        $capabilities = Request $cli @{ op = 'getCapabilities' }
        $cold.Stop()
        if (!$capabilities.result.available) { throw "$backend reported unavailable." }
        $windows = (Request $cli @{ op = 'listWindows' }).result
        $match = @($windows | Where-Object { $_.processId -eq $fixture.Id -and $_.name -ceq $title })
        if ($match.Count -ne 1) { throw 'Cannot uniquely identify the temporary WPF window.' }
        $samples = New-Object 'Collections.Generic.List[object]'
        $elementCount = $null
        for ($i = 0; $i -le $Iterations; $i++) {
            $snap = Request $cli @{ op = 'snapshot'; windowId = $match[0].windowId; maxDepth = 16; maxElements = 200 }
            $count = $snap.result.elements.Count
            if ($snap.result.truncated -or ($null -ne $elementCount -and $count -ne $elementCount)) {
                throw 'The fixture tree was truncated or its size changed.'
            }
            $elementCount = $count
            $edit = Request $cli @{ op = 'findElement'; snapshotId = $snap.result.snapshotId
                locator = @{ automationId = 'fixtureEdit'; role = 'Edit' } }
            $button = Request $cli @{ op = 'findElement'; snapshotId = $snap.result.snapshotId
                locator = @{ automationId = 'fixtureIncrement'; role = 'Button' } }
            $value = "sample-$i"
            $set = Request $cli @{ op = 'setValue'; ref = $edit.result.ref; value = $value }
            Wait-State 'value.txt' $value
            $previous = [int][IO.File]::ReadAllText((Join-Path $stateDir 'count.txt'))
            $invoke = Request $cli @{ op = 'invoke'; ref = $button.result.ref }
            Wait-State 'count.txt' ([string]($previous + 1))
            if ($i -gt 0) {
                $samples.Add([ordered]@{ iteration = $i; snapshotMs = $snap.ms; findEditMs = $edit.ms
                    findButtonMs = $button.ms; setValueMs = $set.ms; invokeMs = $invoke.ms })
            }
        }
        return [ordered]@{ backend = $backend; processStartToCapabilitiesMs = $cold.Elapsed.TotalMilliseconds
            elementsPerSnapshot = $elementCount; samples = $samples.ToArray()
            javaMemory = Memory-Sample $cli; workerMemory = Memory-Sample (Worker-Process $cli) }
    } finally {
        $cli.StandardInput.BaseStream.Close()
        if (!$cli.WaitForExit(20000)) {
            $worker = Worker-Process $cli
            if ($worker) { $worker.Kill() }
            $cli.Kill()
            $cli.WaitForExit()
        }
        $cli.Dispose()
    }
}

$stateDir = Join-Path ([IO.Path]::GetTempPath()) ("uia-compare-" + [guid]::NewGuid())
[void][IO.Directory]::CreateDirectory($stateDir)
$title = 'UIA comparison ' + [guid]::NewGuid()
$fixture = $null
try {
    $fixture = Start-Process -FilePath $fixtureExe -PassThru -ArgumentList @(
        '-NoProfile', '-NonInteractive', '-STA', '-ExecutionPolicy', 'RemoteSigned',
        '-File', "`"$fixtureScript`"", "`"$stateDir`"", "`"$title`"")
    Wait-State 'ready' ([string]$fixture.Id)
    $order = @('PowerShell', 'CSharp' | Get-Random -Count 2)
    $results = @(foreach ($backend in $order) { Measure-Backend $backend })
    if ($results[0].elementsPerSnapshot -ne $results[1].elementsPerSnapshot) { throw 'Backend tree sizes differ.' }
    [ordered]@{ utc = [DateTime]::UtcNow.ToString('o'); os = [Environment]::OSVersion.VersionString
        iterations = $Iterations; warmupIterations = 1; order = $order; results = $results
    } | ConvertTo-Json -Depth 8
} finally {
    if ($fixture -and !$fixture.HasExited) { $fixture.Kill(); $fixture.WaitForExit() }
    if ($fixture) { $fixture.Dispose() }
    Remove-Item -LiteralPath $stateDir -Recurse -Force
}
