param([Parameter(Mandatory)][string]$StateDirectory, [Parameter(Mandatory)][string]$WindowTitle)
$ErrorActionPreference = 'Stop'

Add-Type -AssemblyName PresentationFramework
Add-Type -TypeDefinition @'
using System;
using System.ComponentModel;
using System.Runtime.InteropServices;
public static class FixtureCursor {
    [StructLayout(LayoutKind.Sequential)]
    private struct Point { public int X, Y; }
    [DllImport("user32.dll", SetLastError = true)]
    private static extern bool GetPhysicalCursorPos(out Point point);
    public static string Position() {
        Point point;
        if (!GetPhysicalCursorPos(out point)) throw new Win32Exception();
        return point.X + "," + point.Y;
    }
}
'@

function Write-State([string]$FileName, [string]$Value) {
    [IO.File]::WriteAllText((Join-Path $StateDirectory $FileName), $Value)
}

$window = New-Object Windows.Window
$window.Title = $WindowTitle
$window.Width = 350
$window.Height = 250
$panel = New-Object Windows.Controls.StackPanel
$window.Content = $panel

$edit = New-Object Windows.Controls.TextBox
[Windows.Automation.AutomationProperties]::SetAutomationId($edit, 'fixtureEdit')
$edit.Add_TextChanged({ Write-State 'value.txt' $edit.Text })
$edit.Text = 'initial fixture value'
[void]$panel.Children.Add($edit)

$script:clickCount = 0
Write-State 'count.txt' '0'
foreach ($caption in @('Increment fixture counter', 'Duplicate label', 'Duplicate label')) {
    $button = New-Object Windows.Controls.Button
    $button.Content = $caption
    [Windows.Automation.AutomationProperties]::SetName($button, $caption)
    if ($caption -eq 'Increment fixture counter') {
        [Windows.Automation.AutomationProperties]::SetAutomationId($button, 'fixtureIncrement')
        $button.Add_Click({
            $script:clickCount++
            Write-State 'count.txt' ([string]$script:clickCount)
        })
    }
    [void]$panel.Children.Add($button)
}

# A unique filename per sample prevents a delayed response from satisfying the next read.
$timer = New-Object Windows.Threading.DispatcherTimer
$timer.Interval = [TimeSpan]::FromMilliseconds(25)
$timer.Add_Tick({
    foreach ($request in [IO.Directory]::GetFiles($StateDirectory, '*.request')) {
        $position = [FixtureCursor]::Position()
        $reply = [IO.Path]::ChangeExtension($request, 'reply')
        [IO.File]::WriteAllText("$reply.tmp", $position)
        [IO.File]::Move("$reply.tmp", $reply)
        [IO.File]::Delete($request)
    }
})
$window.Add_ContentRendered({
    Write-State 'ready' ([string]$PID)
    $timer.Start()
})
[void]$window.ShowDialog()
$timer.Stop()
