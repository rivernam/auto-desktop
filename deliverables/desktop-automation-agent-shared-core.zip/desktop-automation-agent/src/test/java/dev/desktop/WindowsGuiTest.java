package dev.desktop;

import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.node.JsonNodeFactory;
import com.fasterxml.jackson.databind.node.ObjectNode;
import java.awt.GraphicsEnvironment;
import java.io.IOException;
import java.io.InputStream;
import java.nio.file.Files;
import java.nio.file.Path;
import java.time.Duration;
import java.util.Set;
import java.util.UUID;
import java.util.concurrent.TimeUnit;
import java.util.function.Supplier;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.condition.EnabledIfSystemProperty;
import org.junit.jupiter.api.io.TempDir;

import static org.junit.jupiter.api.Assertions.*;

class WindowsGuiTest {
    @TempDir Path directory;

    @Test
    @EnabledIfSystemProperty(named = "desktop.windowsIT", matches = "true")
    void operatesDedicatedWpfWindowWithoutMovingPhysicalCursor() throws Exception {
        verifyWpfWindow(WindowsAdapter::new);
    }

    @Test
    @EnabledIfSystemProperty(named = "desktop.csharpIT", matches = "true")
    void csharpWorkerOperatesDedicatedWpfWindowWithoutMovingPhysicalCursor() throws Exception {
        String configured = System.getProperty("desktop.csharpWorker");
        assertTrue(configured != null && !configured.isBlank(), "Specify -Ddesktop.csharpWorker=<absolute exe path>.");
        Path executable = Path.of(configured);
        assertTrue(executable.isAbsolute() && Files.isRegularFile(executable),
                "desktop.csharpWorker must be the absolute path of a published worker executable.");
        verifyWpfWindow(() -> WindowsAdapter.forCSharpWorker(executable));
    }

    private void verifyWpfWindow(Supplier<WindowsAdapter> adapterFactory) throws Exception {
        String os = System.getProperty("os.name");
        assertTrue(Set.of("Windows 10", "Windows 11").contains(os),
                "This test requires an interactive Windows 10 or 11 desktop. Detected " + os);
        assertFalse(GraphicsEnvironment.isHeadless(), "This test requires an interactive desktop.");
        Path script = directory.resolve("fixture.ps1");
        try (InputStream resource = getClass().getResourceAsStream("/windows-gui-fixture.ps1")) {
            assertNotNull(resource);
            Files.copy(resource, script);
        }
        String title = "Desktop agent fixture " + UUID.randomUUID();
        Path powershell = Path.of(System.getenv("SystemRoot"), "System32", "WindowsPowerShell",
                "v1.0", "powershell.exe");
        Process fixture = new ProcessBuilder(powershell.toString(), "-NoProfile", "-NonInteractive", "-STA",
                "-ExecutionPolicy", "RemoteSigned", "-File", script.toString(), directory.toString(), title)
                .redirectErrorStream(true).redirectOutput(directory.resolve("fixture.log").toFile()).start();
        try {
            int pid = Math.toIntExact(fixture.pid());
            awaitFile(fixture, "ready", Integer.toString(pid));
            try (WindowsAdapter adapter = adapterFactory.get()) {
                Agent agent = new Agent(adapter, Set.of(pid), Set.of("invoke", "setValue"));
                JsonNode capabilities = result(agent, request("getCapabilities"));
                assertTrue(capabilities.path("available").asBoolean(), capabilities::toString);
                assertEquals("UIA", capabilities.path("backend").asText());
                assertFalse(capabilities.path("physicalInput").asBoolean(true));

                JsonNode windows = result(agent, request("listWindows"));
                assertTrue(windows.isArray());
                String windowId = null;
                for (JsonNode window : windows) {
                    if (window.path("processId").asInt() == pid && title.equals(window.path("name").asText())) {
                        assertNull(windowId, "Multiple windows claim the fixture identity.");
                        windowId = window.path("windowId").textValue();
                    }
                }
                assertNotNull(windowId, "Dedicated fixture window was absent from listWindows.");
                assertFalse(windowId.isBlank());

                JsonNode snapshot = result(agent, request("snapshot").put("windowId", windowId));
                assertTrue(snapshot.path("elements").isArray());
                assertFalse(snapshot.path("elements").isEmpty());
                assertFalse(snapshot.toString().contains("initial fixture value"), "Input value leaked in snapshot.");
                String snapshotId = snapshot.path("snapshotId").textValue();
                assertNotNull(snapshotId);
                String edit = result(agent, find(snapshotId, "automationId", "fixtureEdit", "Edit")).get("ref").asText();
                String button = result(agent, find(snapshotId, "name", "Increment fixture counter", "Button")).get("ref").asText();
                assertNotEquals(button, edit);
                JsonNode info = result(agent, request("getElementInfo").put("ref", button));
                assertEquals("fixtureIncrement", info.path("automationId").textValue());
                assertEquals("Button", info.path("role").textValue());
                assertEquals("UIA", info.path("backend").textValue());
                assertEquals(pid, info.path("processId").asInt());
                assertEquals(button, info.path("ref").textValue());
                assertTrue(info.path("enabled").asBoolean());
                assertTrue(info.path("bounds").path("width").asDouble() > 0);
                assertTrue(info.path("actions").isArray());

                error(agent, find(snapshotId, "name", "Duplicate label", "Button"), "AMBIGUOUS_ELEMENT");
                error(agent, request("invoke").put("ref", edit), "PATTERN_UNSUPPORTED");
                awaitFile(fixture, "count.txt", "0");
                awaitFile(fixture, "value.txt", "initial fixture value");

                String cursor = cursor(fixture);
                String expected = "changed by UIA \u2713";
                assertTrue(result(agent, request("setValue").put("ref", edit).put("value", expected))
                        .path("performed").asBoolean());
                awaitFile(fixture, "value.txt", expected);
                assertEquals(cursor, cursor(fixture), "Physical cursor moved during setValue.");

                ObjectNode invoke = request("invoke").put("ref", button);
                assertTrue(result(agent, invoke).path("performed").asBoolean());
                awaitFile(fixture, "count.txt", "1");
                assertEquals(cursor, cursor(fixture), "Physical cursor moved during invoke.");
                error(agent, invoke, "DUPLICATE_COMMAND");
                awaitFile(fixture, "count.txt", "1");

                JsonNode refreshed = result(agent, request("snapshot").put("windowId", windowId));
                assertFalse(refreshed.toString().contains(expected), "Changed input value leaked in snapshot.");
                error(agent, request("getElementInfo").put("ref", edit), "STALE_REFERENCE");

                String freshEdit = result(agent, find(refreshed.get("snapshotId").asText(),
                        "automationId", "fixtureEdit", "Edit")).get("ref").asText();
                result(agent, request("getElementInfo").put("ref", freshEdit));
                fixture.destroyForcibly();
                assertTrue(fixture.waitFor(10, TimeUnit.SECONDS), "Fixture did not exit.");
                error(agent, request("getElementInfo").put("ref", freshEdit), "STALE_REFERENCE");
            }
        } finally {
            fixture.destroyForcibly();
            assertTrue(fixture.waitFor(10, TimeUnit.SECONDS), "Fixture did not exit.");
        }
    }

    private static ObjectNode request(String op) {
        return JsonNodeFactory.instance.objectNode().put("op", op).put("id", UUID.randomUUID().toString());
    }

    private static ObjectNode find(String snapshotId, String field, String value, String role) {
        ObjectNode command = request("findElement").put("snapshotId", snapshotId);
        command.putObject("locator").put(field, value).put("role", role);
        return command;
    }

    private static JsonNode result(Agent agent, ObjectNode command) {
        JsonNode response = agent.handle(command);
        assertTrue(response.path("ok").asBoolean(), response::toString);
        return response.get("result");
    }

    private static void error(Agent agent, ObjectNode command, String code) {
        JsonNode response = agent.handle(command);
        assertFalse(response.path("ok").asBoolean(true), response::toString);
        assertEquals(code, response.at("/error/code").textValue(), response::toString);
    }

    private String cursor(Process fixture) throws Exception {
        String sample = UUID.randomUUID().toString();
        Files.createFile(directory.resolve(sample + ".request"));
        String coordinates = awaitFile(fixture, sample + ".reply", null);
        assertTrue(coordinates.matches("-?\\d+,-?\\d+"), "Invalid physical cursor sample.");
        return coordinates;
    }

    private String awaitFile(Process fixture, String name, String expected) throws Exception {
        Path path = directory.resolve(name);
        long deadline = System.nanoTime() + Duration.ofSeconds(20).toNanos();
        while (System.nanoTime() < deadline && fixture.isAlive()) {
            if (Files.exists(path)) {
                String value = Files.readString(path);
                if (expected == null || expected.equals(value)) return value;
            }
            Thread.sleep(40);
        }
        throw new IOException("Fixture failed while waiting for " + name + ". Output: "
                + Files.readString(directory.resolve("fixture.log")));
    }
}
