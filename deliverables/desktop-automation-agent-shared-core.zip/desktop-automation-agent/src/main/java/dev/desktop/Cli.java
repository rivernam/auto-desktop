package dev.desktop;

import com.fasterxml.jackson.core.JsonParser;
import com.fasterxml.jackson.databind.DeserializationFeature;
import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.node.ObjectNode;
import java.io.BufferedInputStream;
import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.nio.ByteBuffer;
import java.nio.charset.StandardCharsets;
import java.nio.file.Path;
import java.time.Instant;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Map;
import java.util.Set;

/** One local foreground session. Every request and response occupies one UTF-8 line. */
public final class Cli {
    private static final Set<String> OPERATIONS = Set.of("getCapabilities", "listWindows", "snapshot",
            "findElement", "getElementInfo", "invoke", "setValue");
    static final int MAX_FRAME = 64 * 1024;
    private static final ObjectMapper JSON = new ObjectMapper()
            .enable(DeserializationFeature.FAIL_ON_TRAILING_TOKENS)
            .enable(JsonParser.Feature.STRICT_DUPLICATE_DETECTION);

    public static void main(String[] args) throws IOException {
        System.exit(run(args, System.in, System.out));
    }

    static int run(String[] args, InputStream input, OutputStream output) throws IOException {
        Map<Integer, Instant> allowedPids = new HashMap<>();
        Set<String> allowedActions = new HashSet<>();
        Path worker = null;
        DesktopAdapter selected;
        try {
            for (int i = 0; i < args.length; i += 2) {
                if (i + 1 >= args.length) throw new IllegalArgumentException();
                String value = args[i + 1];
                switch (args[i]) {
                    case "--csharp-worker" -> {
                        if (worker != null) throw new IllegalArgumentException("Specify one C# worker.");
                        worker = Path.of(value);
                    }
                    case "--allow-pid" -> {
                        int pid = Integer.parseInt(value);
                        if (pid <= 0) throw new IllegalArgumentException();
                        Instant started = ProcessHandle.of(pid).flatMap(handle -> handle.info().startInstant())
                                .orElseThrow(() -> new IllegalArgumentException("Cannot identify allowed PID."));
                        allowedPids.put(pid, started);
                    }
                    case "--allow-action" -> {
                        if (!Set.of("invoke", "setValue").contains(value))
                            throw new IllegalArgumentException();
                        allowedActions.add(value);
                    }
                    default -> throw new IllegalArgumentException();
                }
            }
            selected = DesktopAdapters.open(worker);
        } catch (IllegalArgumentException invalid) {
            System.err.println("Usage: java -jar desktop-agent.jar [--allow-pid PID] "
                    + "[--allow-action invoke] [--allow-action setValue] [--csharp-worker ABSOLUTE_EXE_PATH]");
            System.err.println("Each allowed PID must identify a running process with a readable start time.");
            System.err.println("The optional C# worker path must identify an existing .exe.");
            return 2;
        }
        BufferedInputStream source = new BufferedInputStream(input);
        try (DesktopAdapter adapter = selected) {
            Agent agent = new Agent(adapter, pid -> allowedPids.containsKey(pid)
                    && ProcessHandle.of(pid).filter(ProcessHandle::isAlive)
                            .flatMap(handle -> handle.info().startInstant())
                            .filter(allowedPids.get(pid)::equals).isPresent(), allowedActions);
            ByteArrayOutputStream line = new ByteArrayOutputStream();
            boolean oversized = false;
            long sequence = 0;
            while (true) {
                int ch = source.read();
                if (ch == '\n' || ch == -1) {
                    if (line.size() > 0 || oversized || ch != -1) {
                        ObjectNode reply = dispatch(agent, line, oversized, ++sequence);
                        output.write(JSON.writeValueAsBytes(reply));
                        output.write('\n');
                        output.flush();
                    }
                    if (ch == -1) break;
                    line.reset();
                    oversized = false;
                } else if (line.size() == MAX_FRAME) {
                    oversized = true;
                } else {
                    line.write(ch);
                }
            }
        }
        return 0;
    }

    private static ObjectNode dispatch(Agent agent, ByteArrayOutputStream line, boolean oversized, long sequence) {
        long start = System.nanoTime();
        String op = "invalid";
        ObjectNode reply = invalidRequest();
        try {
            if (!oversized) {
                String frame = StandardCharsets.UTF_8.newDecoder()
                        .decode(ByteBuffer.wrap(line.toByteArray())).toString();
                JsonNode node = JSON.readTree(frame);
                if (node instanceof ObjectNode request) {
                    String requested = request.path("op").asText();
                    if (OPERATIONS.contains(requested)) op = requested;
                    reply = agent.handle(request);
                }
            }
        } catch (IOException malformed) {
            // Parser diagnostics can contain input values. Keep them out of the protocol and logs.
        }
        String status = reply.path("ok").asBoolean() ? "OK" : reply.at("/error/code").asText();
        System.err.printf("%s seq=%d op=%s status=%s elapsedMs=%d%n", Instant.now(), sequence,
                op, status, (System.nanoTime() - start) / 1_000_000L);
        return reply;
    }

    private static ObjectNode invalidRequest() {
        ObjectNode reply = JSON.createObjectNode().putNull("id").put("ok", false);
        reply.putObject("error").put("code", "INVALID_REQUEST")
                .put("message", "Expected one UTF-8 JSON object within the frame limit.");
        return reply;
    }

    private Cli() {}
}
