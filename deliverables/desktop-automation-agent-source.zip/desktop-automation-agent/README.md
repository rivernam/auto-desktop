# Java Desktop Automation Agent

Windows 10/11에서 UI Automation으로 창과 요소를 탐색하고, 요소가 제공하는 InvokePattern과 ValuePattern을 실행하는 로컬 PoC다. Java CLI 한 개를 띄워 두면 같은 세션에서 스냅샷 참조를 사용할 수 있다. 실제 Windows GUI에서의 합격 여부는 [시험 기록](docs/TEST-RESULTS.md)에서 확인할 수 있다.

## 빌드와 실행

JDK 17 이상과 Maven 3.9를 사용한다. 처음 빌드할 때 Maven이 의존성을 내려받는다. 빌드한 JAR에는 Jackson과 UIA 작업 스크립트가 포함된다. Agent 실행에는 외부 서버가 필요하지 않다.

```sh
mvn clean verify
java -jar target/desktop-agent.jar
```

CLI가 실행되면 JSON 한 줄을 입력할 때마다 응답 한 줄을 출력한다. 다음 두 명령은 조회 전용이다.

```jsonl
{"id":"probe","op":"getCapabilities"}
{"id":"windows","op":"listWindows"}
```

Windows에서는 로그인한 사용자의 로컬 대화형 세션에서 대상 앱과 같은 권한 수준으로 실행한다. Windows PowerShell 5.1과 .NET Framework의 UI Automation 어셈블리가 필요하다. 출력된 창의 PID를 확인한 뒤 변경이 필요한 경우에만 새 세션을 시작한다. 아래의 1234는 승인한 테스트 앱의 실제 PID로 바꾼다.

```powershell
java -jar target/desktop-agent.jar --allow-pid 1234 --allow-action invoke --allow-action setValue
```

Windows 통합 테스트는 독립된 WPF 창을 만들고 해당 PID만 허용한다. Windows 10/11 테스트 데스크톱에서 마우스를 건드리지 않고 실행한다.

```powershell
mvn '-Ddesktop.windowsIT=true' '-Dtest=WindowsGuiTest' test
```

## 문서

- [명령 예제, JSON 모델과 오류 코드](docs/API.md)
- [실행 구조와 Phase 2~5 개발 계획](docs/ARCHITECTURE.md)
- [접근성 기술 선택 근거 및 원본 자료](docs/TECHNOLOGY-DECISIONS.md)
- [OS·런타임 호환성 및 레거시 검증 전략](docs/COMPATIBILITY.md)
- [빌드·테스트 결과와 남은 실기기 시험](docs/TEST-RESULTS.md)
