package dev.desktop;

import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.node.ObjectNode;

/** Synchronous boundary to one local accessibility worker. */
public interface DesktopAdapter extends AutoCloseable {
    JsonNode call(ObjectNode request);
    @Override void close();
}
