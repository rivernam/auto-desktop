package dev.desktop;

import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.node.JsonNodeFactory;
import com.fasterxml.jackson.databind.node.ObjectNode;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.HashSet;
import java.util.Map;
import java.util.Set;
import java.util.UUID;
import java.util.concurrent.TimeUnit;
import java.util.function.IntPredicate;
import java.util.function.LongSupplier;

/** One serialized client session, scoped to the most recent successful snapshot. */
public final class Agent {
    private static final Set<String> LOCATOR_FIELDS = Set.of("name", "role", "automationId", "className");
    private static final long TTL_NANOS = TimeUnit.SECONDS.toNanos(120);
    private static final int COMMAND_HISTORY = 4096;

    private final DesktopAdapter adapter;
    private final IntPredicate allowedProcess;
    private final Set<String> allowedActions;
    private final LongSupplier nanoTime;
    private final Set<String> commandIds = new HashSet<>();
    private final Map<String, ObjectNode> elements = new LinkedHashMap<>();
    private final Map<String, String> references = new HashMap<>();
    private String snapshotId;
    private boolean truncated;
    private long capturedAt;

    public Agent(DesktopAdapter adapter, Set<Integer> allowedPids, Set<String> allowedActions) {
        this(adapter, allowedPids, allowedActions, System::nanoTime);
    }

    public Agent(DesktopAdapter adapter, IntPredicate allowedProcess, Set<String> allowedActions) {
        this(adapter, allowedProcess, allowedActions, System::nanoTime);
    }

    Agent(DesktopAdapter adapter, Set<Integer> allowedPids, Set<String> allowedActions, LongSupplier nanoTime) {
        this(adapter, Set.copyOf(allowedPids)::contains, allowedActions, nanoTime);
    }

    private Agent(DesktopAdapter adapter, IntPredicate allowedProcess, Set<String> allowedActions, LongSupplier nanoTime) {
        this.adapter = adapter;
        this.allowedProcess = allowedProcess;
        this.allowedActions = Set.copyOf(allowedActions);
        this.nanoTime = nanoTime;
    }

    private static ObjectNode object() {
        return JsonNodeFactory.instance.objectNode();
    }

    public synchronized ObjectNode handle(ObjectNode request) {
        ObjectNode response = object().putNull("id");
        try {
            if (request == null) throw invalid("Expected a request object.");
            String id = string(request, "id", 128, false);
            response.put("id", id);
            String op = string(request, "op", 32, false);
            ObjectNode worker = object().put("op", op);
            JsonNode result = switch (op) {
                case "getCapabilities", "listWindows" -> adapter.call(worker);
                case "snapshot" -> snapshot(request, worker);
                case "findElement" -> find(request);
                case "getElementInfo", "invoke", "setValue" -> elementOperation(request, worker, op, id);
                default -> throw new AgentException("UNKNOWN_OPERATION", "Unknown operation.");
            };
            response.put("ok", true).set("result", result);
        } catch (AgentException ex) {
            response.put("ok", false).putObject("error").put("code", ex.code()).put("message", ex.getMessage());
        } catch (RuntimeException ex) {
            response.put("ok", false).putObject("error").put("code", "INTERNAL_ERROR")
                    .put("message", "The operation could not be completed.");
        }
        return response;
    }

    private ObjectNode snapshot(ObjectNode request, ObjectNode worker) {
        int limit = integer(request, "maxElements", 500, 1, 2000);
        worker.put("windowId", string(request, "windowId", 256, false)).put("maxElements", limit)
                .put("maxDepth", integer(request, "maxDepth", 12, 0, 32));
        // A failed worker call may already have replaced the native element cache.
        snapshotId = null;
        elements.clear();
        references.clear();
        JsonNode raw = adapter.call(worker);
        if (raw == null || !raw.path("truncated").isBoolean() || !raw.path("elements").isArray()
                || raw.get("elements").size() > limit) throw badWorker();
        for (JsonNode row : raw.get("elements")) {
            if (!(row instanceof ObjectNode element) || !row.path("key").isTextual()
                    || row.get("key").textValue().isBlank() || !row.path("processId").isIntegralNumber()
                    || !row.get("processId").canConvertToInt() || row.get("processId").intValue() <= 0
                    || !row.path("actions").isArray() || !row.path("enabled").isBoolean()) throw badWorker();
            String key = row.get("key").textValue();
            String ref = UUID.randomUUID().toString();
            if (references.putIfAbsent(key, ref) != null) throw badWorker();
            elements.put(ref, element.deepCopy());
        }
        ObjectNode result = object();
        var rows = result.putArray("elements");
        elements.forEach((ref, element) -> rows.add(publicElement(ref, element)));
        snapshotId = UUID.randomUUID().toString();
        capturedAt = nanoTime.getAsLong();
        truncated = raw.get("truncated").booleanValue();
        return result.put("snapshotId", snapshotId).put("windowId", worker.get("windowId").textValue())
                .put("truncated", truncated);
    }

    private ObjectNode publicElement(String ref, ObjectNode element) {
        ObjectNode result = element.deepCopy();
        result.remove("key");
        JsonNode parentKey = result.remove("parentKey");
        String parentRef = null;
        if (parentKey != null && !parentKey.isNull()) {
            parentRef = references.get(parentKey.textValue());
            if (parentRef == null) throw badWorker();
        }
        return result.put("ref", ref).put("parentRef", parentRef);
    }

    private ObjectNode find(ObjectNode request) {
        String requestedSnapshot = string(request, "snapshotId", 128, false);
        checkLive();
        if (!requestedSnapshot.equals(snapshotId)) throw stale();
        if (!(request.get("locator") instanceof ObjectNode locator) || locator.size() == 0)
            throw invalid("Provide one or more locator fields.");
        locator.fieldNames().forEachRemaining(field -> {
            if (!LOCATOR_FIELDS.contains(field)) throw invalid("Unknown locator field.");
            string(locator, field, 4096, true);
        });
        String match = null;
        for (var entry : elements.entrySet()) {
            if (matches(entry.getValue(), locator)) {
                if (match != null) throw new AgentException("AMBIGUOUS_ELEMENT", "More than one element matches.");
                match = entry.getKey();
            }
        }
        if (truncated) throw new AgentException("INCOMPLETE_SNAPSHOT", "A complete snapshot is required for lookup.");
        if (match == null) throw new AgentException("ELEMENT_NOT_FOUND", "No element matches the locator.");
        return publicElement(match, elements.get(match));
    }

    private static boolean matches(ObjectNode element, ObjectNode locator) {
        var fields = locator.properties().iterator();
        while (fields.hasNext()) {
            var field = fields.next();
            if (!field.getValue().equals(element.get(field.getKey()))) return false;
        }
        return true;
    }

    private JsonNode elementOperation(ObjectNode request, ObjectNode worker, String op, String id) {
        boolean mutation = !op.equals("getElementInfo");
        if (mutation && commandIds.contains(id))
            throw new AgentException("DUPLICATE_COMMAND", "This command ID has already been dispatched.");
        String ref = string(request, "ref", 128, false);
        checkLive();
        ObjectNode element = elements.get(ref);
        if (element == null) throw stale();
        int pid = element.get("processId").intValue();
        String key = element.get("key").textValue();
        worker.put("key", key).put("processId", pid);
        if (!mutation) {
            JsonNode info = adapter.call(worker);
            if (!(info instanceof ObjectNode row) || !element.get("key").equals(row.get("key"))
                    || !element.get("processId").equals(row.get("processId"))) throw badWorker();
            return publicElement(ref, row);
        }
        if (!allowedProcess.test(pid) || !allowedActions.contains(op))
            throw new AgentException("PERMISSION_DENIED", "The process and action must both be allowed.");
        if (!element.get("enabled").booleanValue())
            throw new AgentException("PRECONDITION_FAILED", "The element is disabled.");
        if (!offers(element.get("actions"), op))
            throw new AgentException("PATTERN_UNSUPPORTED", "The element does not support this action.");
        if (op.equals("setValue")) worker.put("value", string(request, "value", 16384, true));
        // A timeout can occur after the native action has taken effect.
        if (commandIds.size() >= COMMAND_HISTORY)
            throw new AgentException("SESSION_LIMIT", "Start a new agent session to dispatch more commands.");
        commandIds.add(id);
        try {
            return adapter.call(worker);
        } catch (AgentException ex) {
            if (ex.code().equals("TIMEOUT"))
                throw new AgentException("ACTION_OUTCOME_UNKNOWN", "The action timed out. Inspect the target before retrying.");
            throw ex;
        }
    }

    private static boolean offers(JsonNode actions, String op) {
        for (JsonNode action : actions) if (op.equals(action.textValue())) return true;
        return false;
    }

    private void checkLive() {
        if (snapshotId == null || nanoTime.getAsLong() - capturedAt >= TTL_NANOS) throw stale();
    }

    private static String string(ObjectNode node, String field, int limit, boolean allowEmpty) {
        JsonNode value = node.path(field);
        if (!value.isTextual() || value.textValue().length() > limit
                || (!allowEmpty && value.textValue().isBlank())) throw invalid("Invalid " + field + ".");
        return value.textValue();
    }

    private static int integer(ObjectNode node, String field, int fallback, int min, int max) {
        if (!node.has(field)) return fallback;
        JsonNode value = node.get(field);
        if (!value.isIntegralNumber() || !value.canConvertToInt() || value.intValue() < min || value.intValue() > max)
            throw invalid("Invalid " + field + ".");
        return value.intValue();
    }

    private static AgentException stale() {
        return new AgentException("STALE_REFERENCE", "Capture a new snapshot and resolve the element again.");
    }

    private static AgentException invalid(String message) {
        return new AgentException("INVALID_REQUEST", message);
    }

    private static AgentException badWorker() {
        return new AgentException("WORKER_PROTOCOL", "Invalid response from the accessibility worker.");
    }
}
