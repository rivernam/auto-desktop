package dev.desktop;

import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.node.JsonNodeFactory;
import com.fasterxml.jackson.databind.node.ObjectNode;
import java.util.Set;
import java.util.concurrent.TimeUnit;
import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

class AgentTest {
    private static ObjectNode object() {
        return JsonNodeFactory.instance.objectNode();
    }

    private static ObjectNode request(String op) {
        return object().put("id", "request-" + op).put("op", op);
    }

    private static final class FakeDesktop implements DesktopAdapter {
        boolean truncated;
        boolean duplicateName;
        boolean timeout;
        boolean enabled = true;
        boolean disappeared;
        boolean canInvoke;
        int invokes;
        int writes;
        String value = "";

        ObjectNode element(String key) {
            ObjectNode row = object().put("key", key).putNull("parentKey").put("name", "Title")
                    .put("role", "Edit").put("automationId", "title").put("className", "TextBox")
                    .put("enabled", enabled).put("processId", 42);
            var actions = row.putArray("actions").add("setValue");
            if (canInvoke) actions.add("invoke");
            return row;
        }

        public JsonNode call(ObjectNode request) {
            return switch (request.path("op").asText()) {
                case "snapshot" -> {
                    ObjectNode snapshot = object().put("truncated", truncated);
                    var elements = snapshot.putArray("elements").add(element("private-key"));
                    if (duplicateName) elements.add(element("another-key").put("parentKey", "private-key"));
                    yield snapshot;
                }
                case "getElementInfo" -> {
                    if (disappeared) throw new AgentException("STALE_REFERENCE", "Element has gone.");
                    yield element("private-key");
                }
                case "invoke" -> {
                    assertEquals(42, request.path("processId").asInt());
                    assertEquals("private-key", request.path("key").asText());
                    invokes++;
                    yield object().put("performed", true);
                }
                case "setValue" -> {
                    assertEquals(42, request.path("processId").asInt());
                    assertEquals("private-key", request.path("key").asText());
                    value = request.path("value").textValue();
                    writes++;
                    if (timeout) throw new AgentException("TIMEOUT", "Worker timed out.");
                    yield object().put("performed", true);
                }
                default -> throw new AssertionError(request);
            };
        }

        public void close() {}
    }

    private final FakeDesktop desktop = new FakeDesktop();
    private long nanos;
    private final Agent agent = new Agent(desktop, Set.of(42), Set.of("setValue"), () -> nanos);

    private static JsonNode snapshot(Agent agent) {
        JsonNode response = agent.handle(request("snapshot").put("windowId", "window-1"));
        assertTrue(response.path("ok").asBoolean(), response::toString);
        return response.get("result");
    }

    private static String ref(JsonNode snapshot) {
        return snapshot.at("/elements/0/ref").textValue();
    }

    private static ObjectNode write(String ref) {
        return request("setValue").put("ref", ref).put("value", "new title");
    }

    private static void error(String code, JsonNode response) {
        assertFalse(response.path("ok").asBoolean(true));
        assertEquals(code, response.at("/error/code").textValue());
    }

    private static ObjectNode find(JsonNode snapshot) {
        ObjectNode request = request("findElement").put("snapshotId", snapshot.get("snapshotId").asText());
        request.putObject("locator").put("name", "Title").put("role", "Edit");
        return request;
    }

    @Test void referencesHideKeysAndRetainParentRelation() {
        desktop.duplicateName = true;
        var snapshot = snapshot(agent);
        assertEquals(ref(snapshot), snapshot.at("/elements/1/parentRef").textValue());
        assertFalse(snapshot.toString().contains("private-key"));
        var info = agent.handle(request("getElementInfo").put("ref", ref(snapshot)));
        assertEquals("Title", info.at("/result/name").asText());
        assertFalse(info.toString().contains("private-key"));
    }

    @Test void exactLocatorRequiresUniqueMatchAndCompleteSearch() {
        var snapshot = snapshot(agent);
        assertEquals(ref(snapshot), agent.handle(find(snapshot)).at("/result/ref").textValue());
        desktop.duplicateName = true;
        error("AMBIGUOUS_ELEMENT", agent.handle(find(snapshot(agent))));
        desktop.duplicateName = false;
        desktop.truncated = true;
        error("INCOMPLETE_SNAPSHOT", agent.handle(find(snapshot(agent))));
    }

    @Test void replacedAndExpiredReferencesNeverDispatch() {
        String old = ref(snapshot(agent));
        String current = ref(snapshot(agent));
        error("STALE_REFERENCE", agent.handle(write(old)));
        nanos += TimeUnit.MINUTES.toNanos(3);
        error("STALE_REFERENCE", agent.handle(write(current)));
        assertEquals(0, desktop.writes);
    }

    @Test void failedWriteCannotBeReplayedByReusingCommandId() {
        ObjectNode command = write(ref(snapshot(agent)));
        desktop.timeout = true;
        error("ACTION_OUTCOME_UNKNOWN", agent.handle(command));
        error("DUPLICATE_COMMAND", agent.handle(command));
        assertEquals("new title", desktop.value);
        assertEquals(1, desktop.writes);
    }

    @Test void bothProcessAndActionPermissionsAreRequired() {
        for (Agent restricted : new Agent[] {
                new Agent(desktop, Set.of(), Set.of("setValue")),
                new Agent(desktop, Set.of(7), Set.of("setValue")),
                new Agent(desktop, Set.of(42), Set.of("invoke"))}) {
            error("PERMISSION_DENIED", restricted.handle(write(ref(snapshot(restricted)))));
        }
        assertEquals(0, desktop.writes);
    }

    @Test void disabledElementCannotBeChanged() {
        desktop.enabled = false;
        error("PRECONDITION_FAILED", agent.handle(write(ref(snapshot(agent)))));
        assertEquals(0, desktop.writes);
    }

    @Test void setValueSupportsEmptyString() {
        var result = agent.handle(write(ref(snapshot(agent))).put("value", ""));
        assertTrue(result.path("ok").asBoolean(), result::toString);
        assertEquals("", desktop.value);
        assertEquals(1, desktop.writes);
    }

    @Test void unknownFieldsCannotBroadenALocator() {
        var request = find(snapshot(agent));
        ((ObjectNode) request.get("locator")).put("index", 0);
        error("INVALID_REQUEST", agent.handle(request));
    }

    @Test void outOfRangeTraversalLimitsAreRejected() {
        for (var bad : new ObjectNode[] {
                request("snapshot").put("maxDepth", -1), request("snapshot").put("maxDepth", 33),
                request("snapshot").put("maxElements", 0), request("snapshot").put("maxElements", 2001),
                request("snapshot").put("maxDepth", 1.1)}) {
            error("INVALID_REQUEST", agent.handle(bad.put("windowId", "window-1")));
        }
    }

    @Test void freshSessionRejectsReferencesEvenIfNativeKeysAreReused() {
        String previous = ref(snapshot(agent));
        Agent restarted = new Agent(desktop, Set.of(42), Set.of("setValue"));
        snapshot(restarted);
        error("STALE_REFERENCE", restarted.handle(write(previous)));
        assertEquals(0, desktop.writes);
    }

    @Test void workerCanInvalidateCachedElement() {
        String previous = ref(snapshot(agent));
        desktop.disappeared = true;
        error("STALE_REFERENCE", agent.handle(request("getElementInfo").put("ref", previous)));
    }

    @Test void invokeRequiresSupportedPattern() {
        Agent buttons = new Agent(desktop, Set.of(42), Set.of("invoke"));
        error("PATTERN_UNSUPPORTED", buttons.handle(request("invoke").put("ref", ref(snapshot(buttons)))));
        desktop.canInvoke = true;
        var result = buttons.handle(request("invoke").put("ref", ref(snapshot(buttons))));
        assertTrue(result.at("/result/performed").asBoolean());
        assertEquals(1, desktop.invokes);
    }

    @Test void fullCommandHistoryRejectsFurtherDispatchAndProtectsOldIds() {
        ObjectNode command = write(ref(snapshot(agent)));
        for (int i = 0; i < 4096; i++) {
            assertTrue(agent.handle(command.put("id", Integer.toString(i))).path("ok").asBoolean());
        }
        error("SESSION_LIMIT", agent.handle(command.put("id", "new")));
        error("DUPLICATE_COMMAND", agent.handle(command.put("id", "0")));
        assertEquals(4096, desktop.writes);
    }
}
